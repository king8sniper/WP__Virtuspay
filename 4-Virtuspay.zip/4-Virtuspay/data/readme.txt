++++++++++++++++++ server ++++++++++++++
https://secure.xserver.ne.jp/xapanel/login/xserver/server/
ID: phc64246
PW: w5jr1xbv
++++++++++++++++++ wordpress ++++++++++++++++
URL: https://lexion13.xsrv.jp/wp-admin
ID: admin
PW: Mooz4ies

URL: https://lexion13.xsrv.jp/test/wp-admin
ID: admin
PW: asdasdasd

++++++++++++++++++ SSH ++++++++++++++++
183.90.228.40
lexion13
w5jr1xbv

https://phpmyadmin-sv1139.xserver.jp/?
DB: lexion13_wptest
user: lexion13_wptest
pass: asdasdasd

7cedb43ac7b9d85168804fa4f122216e
c561d61ee7bbe943780077ba96e86d08
c561d61ee7bbe943780077ba96e86d08

